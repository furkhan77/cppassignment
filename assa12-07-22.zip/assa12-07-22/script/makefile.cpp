CC == g++
LFLAGS = -0
CFLAGS=-C-g -Wall -Werror
INC = ./inc
IFLAG= -I$(INC)
BIN = ./bin 
SRC = ./src

all: assa12-07-22

nat: $(OBJ)/assa12-07-22.o

           $(CC) $ (LFLAG) $(BIN)/assa12-07-22 $(OBJ)/assa12-07-22.o

$(OBJ)/assa12-07-22.o: $(SRC)/assa12-07-22.cpp
            $(CC) $(CFLAGS) $(IFLAG) $(SRC)/assa12-07-22.cpp

             mv *.o $(OBJ)

clean:

      rm -f a.out assa12-07-22

      rm-f .0

      rm -f $(OBJ)/*.o rm -f $(BIN)/assa12-07-22