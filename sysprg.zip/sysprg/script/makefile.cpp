CC = g++
CPPFLAGS = -c -Wall
LDFLAGS = -lcppunit -lm
OBJ = obj/
SRC = src/
BIN = bin/
INCLUDE = inc/

all: app

app: $(OBJ)Main.o $(OBJ)test.o $(OBJ)find.o
	$(CC) -o app $(OBJ)Main.o  $(OBJ)tes.o $(OBJ)find.o
	mv app $(BIN) 

$(OBJ)Main.o: $(SRC)Main.cpp
	$(CC) $(CPPFLAGS) $(SRC)Main.cpp -I $(INCLUDE)
	mv Main.o $(OBJ)

$(OBJ)test.o: $(SRC)test.cpp
	$(CC) $(CPPFLAGS) $(SRC)test.cpp -I $(INCLUDE)
	mv test.o $(OBJ)

$(OBJ)find.o: $(SRC)find.cpp
	$(CC) $(CPPFLAGS) $(SRC)find.cpp -I $(INCLUDE)
	mv find.o $(OBJ)


clean:
	rm -f a.out app *.o
	rm -f $(OBJ)*.o
	rm -f $(BIN)app
